# Empresa-VinhoPan
Repositório dedicado a atividade CCComunica da disciplina de Engenharia de Software do Instituto Federal Catarinense - Campus Videira

# Participantes
Os alunos decidiram fazer em grupo, cada um ficou de realizar a sua tarefa destinada. O autor Thiago Dallazen fez as três imagens para as mídias digitais.

Portanto, o autor Felipe Favarin ficou com o restante, fazer o código, as contas digitais nas plataformas Facebook e Instagram, além de fazer os posts em cada uma delas.

# Execução do Código
Para testar o código, faça:
```js
git clone https://github.com/felipebfava/Empresa-VinhoPan.git
```

Escolha um local para melhor localização da pasta, abra num editor de texto e execute o código.

*Dica: Utilize o Visual Studio Code com a extensão Live Server. Com o código index.html aberto, clique em "Go Live" no canto inferior direito, assim o código funcionará".*
